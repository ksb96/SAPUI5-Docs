/* global QUnit */

QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"RouteConfigConnect/RouteConfigConnect/test/integration/AllJourneys"
	], function () {
		QUnit.start();
	});
});
