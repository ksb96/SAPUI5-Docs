sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("employee.EmployeeTable.controller.emp", {
		onInit: function () {

		}
	});
});