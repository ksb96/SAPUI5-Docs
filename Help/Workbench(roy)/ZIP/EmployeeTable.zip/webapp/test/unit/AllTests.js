sap.ui.define([
	"employee/EmployeeTable/test/unit/controller/emp.controller"
], function () {
	"use strict";
});