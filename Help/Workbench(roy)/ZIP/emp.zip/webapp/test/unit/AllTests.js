sap.ui.define([
	"employee/emp/test/unit/controller/View1.controller"
], function () {
	"use strict";
});