sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("employee.emp.controller.View1", {
		onInit: function () {

		}

	});
});