sap.ui.define([
	"com/product/ZProductList/test/unit/controller/View1.controller"
], function () {
	"use strict";
});