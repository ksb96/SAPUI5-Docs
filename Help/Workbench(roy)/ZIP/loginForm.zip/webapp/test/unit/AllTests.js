sap.ui.define([
	"demo/loginForm/test/unit/controller/View1.controller"
], function () {
	"use strict";
});