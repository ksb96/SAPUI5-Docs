sap.ui.define([
	"com/product/ZProductList/controller/BaseController"
], function (BaseController) {
	"use strict";

	return BaseController.extend("com.product.ZProductList.controller.View2", {

		onInit: function () {
	

		}

	});

});