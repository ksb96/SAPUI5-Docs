sap.ui.define([
	"route/RouteConfigPage/test/unit/controller/View1.controller"
], function () {
	"use strict";
});