sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageToast",
	"opensap/w_1/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/Sorter"
], function (Controller, formatter, MessageToast, Filter, FilterOperator, Sorter) {
	"use strict";

	return Controller.extend("opensap.w_1.controller.App", {
		formatter: formatter,
		// u-3
		onShowHello: function () {
			// u-5
			// read msg from i18n model
			var oBundle = this.getView().getModel("i18n").getResourceBundle();
			var sRecipient = this.getView().getModel("helloPanel").getProperty("/recipient/name");
			var sMsg = oBundle.getText("helloMsg", [sRecipient]);

			// show message
			MessageToast.show(sMsg);
			// end of u-5
			// MessageToast.show("Hello World"); //at the bottom of your screen
			// alert("Hello World");
		},
		onSetSorter: function () {

			var oSorter = new Sorter({
				path: "Category",
				descending: false,
				group: true
			});

			var oList = this.byId("productsList");

			oList.getBinding("items").sort(oSorter);

		},

		onFilterProducts: function (oEvent) {

			// build filter array
			var aFilter = [],
				sQuery = oEvent.getParameter("query"),
				// retrieve list control
				oList = this.getView().byId("productsList"),
				// get binding for aggregation 'items'
				oBinding = oList.getBinding("items");

			if (sQuery) {
				aFilter.push(new Filter("ProductID", FilterOperator.Contains, sQuery));
			}
			// apply filter. an empty filter array simply removes the filter
			// which will make all entries visible again
			oBinding.filter(aFilter);
		},

		// w-2 u-5
		onItemSelected: function (oEvent) {
				var oSelectedItem = oEvent.getSource();
				var oContext = oSelectedItem.getBindingContext();
				var sPath = oContext.getPath();
				var oProductDetailPanel = this.byId("productDetailsPanel");

				oProductDetailPanel.bindElement({
					path: sPath
				});
				this.byId("productDetailsPanel").setVisible(true);
			} //end of w-2 u5

	});
	// end of u-3
});