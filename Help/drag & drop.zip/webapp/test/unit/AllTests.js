sap.ui.define([
	"drag/draganddrop/test/unit/controller/View1.controller"
], function () {
	"use strict";
});